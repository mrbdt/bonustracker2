package mf_app.BonusCalculate_3;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class BonusTracker {
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    private static List<Map<String, String>> campaignData;

    public static void main(String[] args) {
        String salesFilePath = "././input_1/bonuses.csv";
        String campaignsFilePath = "./input_2/TO_CHECK_EXAMPLE.csv";
        String reportFilePath = "./output/report.csv";

        try {
            ParsedCSV salesParsedCSV = parseCSV(salesFilePath);
            ParsedCSV campaignsParsedCSV = parseCSV(campaignsFilePath);
            campaignData = campaignsParsedCSV.data;

            List<Map<String, String>> discrepancies = compareSalesWithCampaigns(salesParsedCSV.data, campaignData);
            generateReport(discrepancies, reportFilePath, salesParsedCSV.headers);
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }

    static class ParsedCSV {
        List<String> headers;
        List<Map<String, String>> data;

        public ParsedCSV(List<String> headers, List<Map<String, String>> data) {
            this.headers = headers;
            this.data = data;
        }
    }

    private static ParsedCSV parseCSV(String filePath) throws IOException {
        List<Map<String, String>> data = new ArrayList<>();
        List<String> headersList = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            String[] headers = reader.readNext();
            headersList.addAll(Arrays.asList(headers));
            String[] line;
            while ((line = reader.readNext()) != null) {
                Map<String, String> row = new HashMap<>();
                for (int i = 0; i < headers.length; i++) {
                    row.put(headers[i], line[i]);
                }
                data.add(row);
            }
        }
        return new ParsedCSV(headersList, data);
    }

    private static List<Map<String, String>> compareSalesWithCampaigns(List<Map<String, String>> salesData, List<Map<String, String>> campaignData) throws ParseException {
        List<Map<String, String>> discrepancies = new ArrayList<>();

        for (Map<String, String> sale : salesData) {
            String productBarcode = sale.get("BARCODE");
            int saleQuantity = Integer.parseInt(sale.get("QUANTITY"));
            int saleBonus = Integer.parseInt(sale.get("BONUS"));

            int bestCampaignBonus = 0;
            for (Map<String, String> campaign : campaignData) {
                boolean isEligible = isProductEligibleForCampaign(campaign, productBarcode, saleQuantity);
                if (isEligible) {
                    int campaignBonus = getCampaignBonus(campaign, saleQuantity);
                    if (campaignBonus > bestCampaignBonus && campaignBonus <= saleBonus) {
                        bestCampaignBonus = campaignBonus;
                    }
                }
            }

            int autoApproved = bestCampaignBonus;
            int autoCut = saleBonus - autoApproved;

            Map<String, String> discrepancyRecord = new HashMap<>(sale);
            discrepancyRecord.put("AUTO APPROVED", String.valueOf(autoApproved));
            discrepancyRecord.put("AUTO CUT", String.valueOf(autoCut));
            discrepancies.add(discrepancyRecord);
        }

        return discrepancies;
    }

    private static boolean isProductEligibleForCampaign(Map<String, String> campaign, String productBarcode, int saleQuantity) {
        for (int i = 1; i <= 3; i++) {
            String campaignProductBarcode = campaign.get("PRODUCT_" + i + "_BARCODE");
            if (campaignProductBarcode.equals(productBarcode)) {
                int minOrderQuantity = Integer.parseInt(campaign.get("PRODUCT_" + i + "_MINIMUM_QUANTITY"));
                if (saleQuantity >= minOrderQuantity) {
                    return true;
                }
            }
        }
        return false;
    }

    private static int getCampaignBonus(Map<String, String> campaign, int totalSaleQuantity) {
        int maxCampaignBonus = 0;
        for (int i = 1; i <= 3; i++) {
            String campaignQtyStr = campaign.get("PRODUCT_" + i + "_MINIMUM_QUANTITY");
            if (!campaignQtyStr.isEmpty()) {
                int campaignQty = Integer.parseInt(campaignQtyStr);
                if (totalSaleQuantity >= campaignQty) {
                    int campaignBonus = Integer.parseInt(campaign.get("PRODUCT_" + i + "_MF"));
                    maxCampaignBonus = Math.max(maxCampaignBonus, campaignBonus);
                }
            }
        }
        return maxCampaignBonus;
    }

    private static void generateReport(List<Map<String, String>> discrepancies, String filePath, List<String> headers) throws IOException {
        try (CSVWriter writer = new CSVWriter(new FileWriter(filePath))) {
            writer.writeNext(headers.toArray(new String[0]));
            for (Map<String, String> discrepancy : discrepancies) {
                List<String> record = new ArrayList<>();
                for (String header : headers) {
                    record.add(discrepancy.getOrDefault(header, ""));
                }
                writer.writeNext(record.toArray(new String[0]));
            }
        }
    }
}
